Odefy 
  
From discrete to continuous models in MATLAB.

Version: 1.20
Web:     http://icb.helmholtz-muenchen.de/odefy
GitHub:  http://github.com/krumsieklab/Odefy


Getting started
===============
Please read doc/index.html which is included within this download archive.
Alternatively, go to the Odefy directory in MATLAB or Octave and run

OdefyHelp


License
=======
Odefy is free for academic, non-commerical purposes. For more information,
please refer to LICENSE.txt which is included in this package.

 
Copyright 2008-2019,
Institute of Computational Biology, Helmholtz Zentrum Muenchen, Germany
Krumsiek Lab, Weill Cornell Medicine, New York City, USA